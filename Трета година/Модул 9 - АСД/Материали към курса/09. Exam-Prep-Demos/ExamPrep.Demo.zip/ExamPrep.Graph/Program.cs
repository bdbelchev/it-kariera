﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExamPrep.Graph
{
    class Program
    {
        static long[] memo;

        static long Handshakes(int n)
        {
            if(memo[n] != 0)
            {
                return memo[n];
            }
            else if (n % 2 == 1)
            {
                return 0;
            }
            else if(n == 0)
            {
                return 1;
            }
            else
            {
                long result = 0;

                for (int i = 0; i < n; i+= 2)
                {
                    result += Handshakes(i) * Handshakes(n - 2 - i);
                }

                memo[n] = result;
                return result;
            }
        }

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            memo = new long[n + 1];

            Console.WriteLine(Handshakes(n));
        }
    }
}
