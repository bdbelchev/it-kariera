﻿using System;
using System.Linq;
using System.Numerics;
using System.Text;

namespace ExamPrep.DP
{
    class Program
    {
        private static BigInteger[] calculatedPrices;

        private static bool[] calculated;

        static void Main(string[] args)
        {
            int persons = int.Parse(Console.ReadLine());
            calculatedPrices = new BigInteger[persons];
            calculated = new bool[persons];

            if (persons == 1)
            {
                Console.WriteLine("$1.00");
                return;
            }

            string[,] matrix = new string[persons, persons];

            for (int i = 0; i < persons; i++)
            {
                string input = Console.ReadLine();

                for (int j = 0; j < persons; j++)
                {
                    matrix[i, j] = input[j] + "";
                }
            }

            CalculateNulls(matrix);

            //CALCULATOR ALGO
            for (int i = 0; i < persons; i++)
            {
                RecursiveCalco(matrix, i);
            }

            BigInteger sum = 0;

            for (int i = 0; i < calculatedPrices.Length; i++)
            {
                sum += calculatedPrices[i];
            }

            Console.WriteLine($"${sum:F2}");

            //PrintMatrix(matrix);
        }

        private static void RecursiveCalco(string[,] matrix, int person)
        {
            if (!calculated[person])
            {
                BigInteger currentPrice = 0;
                BigInteger currentCount = 0;

                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    if (matrix[person, col] == "R")
                    {
                        RecursiveCalco(matrix, col);
                        currentPrice += calculatedPrices[col];
                        currentCount++;
                    }
                }

                calculated[person] = true;
                calculatedPrices[person] = currentPrice * currentCount;
            }
        }

        static void CalculateNulls(string[,] matrix)
        {
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                bool isEmpty = true;

                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    if(matrix[row, col] == "R")
                    {
                        isEmpty = false;
                        break;
                    }
                }

                if(isEmpty)
                {
                    calculated[row] = true;
                    calculatedPrices[row] = BigInteger.One;
                }
            }
        }

        static void PrintMatrix(string[,] matrix)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    sb.Append(matrix[i, j] + " ");
                }

                sb.AppendLine();
            }

            Console.WriteLine(sb);
        }
    }
}
